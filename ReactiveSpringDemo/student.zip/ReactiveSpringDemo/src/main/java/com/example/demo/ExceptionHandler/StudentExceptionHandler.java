package com.example.demo.ExceptionHandler;

public class StudentExceptionHandler {

}
